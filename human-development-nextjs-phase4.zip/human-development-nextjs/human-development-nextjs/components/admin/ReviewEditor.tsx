"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { ReflectionReviewRow } from "@/types";

export default function ReviewEditor({ review }: { review: ReflectionReviewRow }) {
  const [humanScore, setHumanScore] = useState<string>(review.human_score?.toString() ?? "");
  const [humanNotes, setHumanNotes] = useState(review.human_notes ?? "");
  const [status, setStatus] = useState<"pending" | "reviewed">(review.status);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const router = useRouter();

  const finalPreview = useMemo(() => {
    if (humanScore === "") return review.ai_score ?? 0;
    const parsed = Number(humanScore);
    return Number.isFinite(parsed) ? parsed : review.ai_score ?? 0;
  }, [humanScore, review.ai_score]);

  async function saveReview() {
    setSaving(true);
    setMessage(null);
    try {
      const parsedScore = humanScore === "" ? null : Number(humanScore);
      const res = await fetch(`/api/admin/reviews/${review.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ humanScore: parsedScore, humanNotes, status }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Failed to save review.");
      setMessage("Saved.");
      router.refresh();
    } catch (err) {
      setMessage(err instanceof Error ? err.message : "Failed to save review.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="review-editor">
      <div className="grid grid-2" style={{ gap: 12 }}>
        <div>
          <div className="small">AI score</div>
          <div style={{ fontSize: 22, fontWeight: 700 }}>{review.ai_score ?? "—"}</div>
          <div className="small">Confidence: {review.ai_confidence ?? "—"}</div>
        </div>
        <div>
          <div className="small">Final reflection score preview</div>
          <div style={{ fontSize: 22, fontWeight: 700 }}>{finalPreview}</div>
          <div className="small">Status: {status}</div>
        </div>
      </div>

      <div style={{ marginTop: 12 }}>
        <div className="small">AI explanation</div>
        <div className="review-box">{review.ai_explanation || "No AI explanation recorded."}</div>
      </div>

      <div className="grid grid-2" style={{ marginTop: 12, gap: 12 }}>
        <div>
          <label className="small">Human override score (0–5)</label>
          <input
            className="input"
            type="number"
            min={0}
            max={5}
            step={0.5}
            value={humanScore}
            onChange={(e) => setHumanScore(e.target.value)}
            placeholder="Leave blank to keep AI score"
          />
        </div>
        <div>
          <label className="small">Review status</label>
          <select className="select" value={status} onChange={(e) => setStatus(e.target.value as "pending" | "reviewed") }>
            <option value="pending">Pending</option>
            <option value="reviewed">Reviewed</option>
          </select>
        </div>
      </div>

      <div style={{ marginTop: 12 }}>
        <label className="small">Human notes</label>
        <textarea
          className="textarea"
          value={humanNotes}
          onChange={(e) => setHumanNotes(e.target.value)}
          placeholder="Why did you keep or override the AI score?"
        />
      </div>

      <div style={{ display: "flex", gap: 12, alignItems: "center", marginTop: 12, flexWrap: "wrap" }}>
        <button type="button" className="button" onClick={saveReview} disabled={saving}>
          {saving ? "Saving..." : "Save review"}
        </button>
        {message ? <span className="small">{message}</span> : null}
      </div>
    </div>
  );
}
