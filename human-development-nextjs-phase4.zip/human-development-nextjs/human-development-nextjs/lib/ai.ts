import OpenAI from "openai";
import { DOMAINS } from "@/lib/domains";

export function getOpenAIClient(): OpenAI {
  if (!process.env.OPENAI_API_KEY) {
    throw new Error("Missing OPENAI_API_KEY.");
  }
  return new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
}

export async function scoreReflectionWithAI(domainId: string, reflection: string) {
  const domain = DOMAINS.find((d) => d.id === domainId);
  if (!domain) throw new Error("Unknown domain.");

  const client = getOpenAIClient();
  const model = process.env.OPENAI_MODEL || "gpt-5-mini";

  const prompt = `You are scoring a reflection answer for a Human Development Self-Assessment.

Domain: ${domain.title}
Definition: ${domain.definition}
Question: ${domain.reflection}

Score the reflection from 0 to 5 using these criteria:
- honesty / realism
- specificity
- self-awareness
- evidence of stabilizing action or developmental capacity

Important constraints:
- This is not a diagnosis.
- Do not reward fancy language.
- Reward concrete, real-life awareness.
- A person can openly describe struggle and still score well if the response is specific and self-aware.
- Return strict JSON only with keys: score, confidence, explanation.
- score must be a number from 0 to 5 in increments of 0.5.
- confidence must be low, medium, or high.
- explanation must be under 90 words.

Reflection:
${reflection}`;

  const response = await client.responses.create({
    model,
    input: prompt,
    text: { format: { type: "json_object" } },
  });

  const rawText = response.output_text;
  const parsed = JSON.parse(rawText);
  return {
    score: Number(parsed.score),
    confidence: String(parsed.confidence),
    explanation: String(parsed.explanation),
  };
}
