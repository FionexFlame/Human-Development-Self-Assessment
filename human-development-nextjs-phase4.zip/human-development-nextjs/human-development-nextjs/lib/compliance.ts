import { cookies } from "next/headers";

export const CONSENT_VERSION = process.env.NEXT_PUBLIC_CONSENT_VERSION || "2026-04-01";
export const CONSENT_COOKIE = "hd_consent_version";

export type EmailPreferenceState = {
  serviceEmails: boolean;
  marketingEmails: boolean;
  consentVersion: string;
  hasConsentedAt?: string | null;
  marketingConsentedAt?: string | null;
  marketingRevokedAt?: string | null;
  allEmailRevokedAt?: string | null;
};

export function getConsentVersion() {
  return CONSENT_VERSION;
}

export async function setConsentCookie() {
  const jar = await cookies();
  jar.set(CONSENT_COOKIE, CONSENT_VERSION, {
    httpOnly: false,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 60 * 60 * 24 * 365,
  });
}

export function getClientIp(headers: Headers) {
  return headers.get("x-forwarded-for")?.split(",")[0]?.trim() || headers.get("x-real-ip") || null;
}

export function getUserAgent(headers: Headers) {
  return headers.get("user-agent") || null;
}

export function getPreferenceSummary(prefs: Partial<EmailPreferenceState>) {
  if (!prefs.serviceEmails && !prefs.marketingEmails) return "All email categories are unsubscribed.";
  if (prefs.serviceEmails && prefs.marketingEmails) return "Service emails and optional follow-up emails are enabled.";
  if (prefs.serviceEmails && !prefs.marketingEmails) return "Service emails are enabled. Optional follow-up emails are off.";
  return "Service emails are off. Optional follow-up emails are on.";
}
