import { NextRequest, NextResponse } from "next/server";
import { DOMAINS } from "@/lib/domains";
import { applyReviewOverrides, computeDomainResult, getOverallProfile, scoreAssessmentBasic } from "@/lib/scoring";
import { scoreReflectionWithAI } from "@/lib/ai";
import { getServiceSupabase } from "@/lib/supabase";
import { sendAssessmentResultEmail, sendMarketingWelcomeEmail } from "@/lib/email";
import { getClientIp, getConsentVersion, getUserAgent, setConsentCookie } from "@/lib/compliance";
import { SubmissionPayload } from "@/types";

function isValidEmail(email: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

export async function POST(request: NextRequest) {
  try {
    const payload = (await request.json()) as SubmissionPayload;

    if (!payload.participantEmail || !isValidEmail(payload.participantEmail)) {
      return NextResponse.json({ error: "A valid email address is required." }, { status: 400 });
    }

    if (!payload.consentToEmail) {
      return NextResponse.json({ error: "Service email consent is required to send and save results." }, { status: 400 });
    }

    const consentVersion = payload.consentVersion || getConsentVersion();
    const consentStatement = "I agree to receive my requested assessment results by email and to have my email stored for this assessment workflow.";
    const ipAddress = getClientIp(request.headers);
    const userAgent = getUserAgent(request.headers);

    const basicResults = scoreAssessmentBasic(payload.answers, payload.reflections);
    let results = basicResults;

    if (payload.scoringMode === "ai" || payload.scoringMode === "review") {
      const aiReflectionEntries = await Promise.all(
        DOMAINS.map(async (domain) => {
          const reflection = payload.reflections[domain.id] ?? "";
          if (!reflection.trim()) {
            return { domainId: domain.id, score: 0, confidence: "low", explanation: "No reflection provided." };
          }
          const ai = await scoreReflectionWithAI(domain.id, reflection);
          return { domainId: domain.id, ...ai };
        })
      );

      results = DOMAINS.map((domain) => {
        const ai = aiReflectionEntries.find((entry) => entry.domainId === domain.id);
        return computeDomainResult({
          domainId: domain.id,
          answers: payload.answers,
          reflections: payload.reflections,
          reflectionScore: ai ? ai.score : undefined,
          reflectionNotes: ai ? [ai.explanation, `AI confidence: ${ai.confidence}`] : undefined,
          reflectionSource: ai ? "ai" : "basic",
        });
      });
    }

    let submissionId: string | null = null;
    let resultUrl: string | null = null;
    let emailStatus: "pending" | "sent" | "failed" | "suppressed" | "not_requested" = "not_requested";

    try {
      const supabase = getServiceSupabase();
      const nowIso = new Date().toISOString();

      const { data: participant } = await supabase
        .from("assessment_participants")
        .upsert(
          {
            email: payload.participantEmail,
            name: payload.participantName || null,
            service_emails_opt_in: true,
            marketing_emails_opt_in: Boolean(payload.marketingConsent),
            service_email_consented_at: nowIso,
            marketing_email_consented_at: payload.marketingConsent ? nowIso : null,
            marketing_email_revoked_at: payload.marketingConsent ? null : nowIso,
            all_email_revoked_at: null,
          },
          { onConflict: "email" }
        )
        .select("id, email, unsubscribe_token, service_emails_opt_in, marketing_emails_opt_in")
        .single();

      const { data, error } = await supabase
        .from("assessment_submissions")
        .insert({
          participant_name: payload.participantName,
          participant_email: payload.participantEmail,
          participant_id: participant?.id ?? null,
          scoring_mode: payload.scoringMode,
          answers: payload.answers,
          reflections: payload.reflections,
          domain_results: results,
          overall_profile: getOverallProfile(results),
          review_status: payload.scoringMode === "review" ? "pending" : "not_required",
          email_delivery_status: "pending",
          consent_version: consentVersion,
          service_email_consent: true,
          marketing_email_consent: Boolean(payload.marketingConsent),
          consent_statement_text: consentStatement,
        })
        .select("id, public_token")
        .single();

      if (error) throw error;
      submissionId = data.id;
      resultUrl = `/results/${submissionId}?token=${data.public_token}`;

      if (participant?.id) {
        await supabase
          .from("assessment_participants")
          .update({ latest_submission_id: submissionId, name: payload.participantName || null })
          .eq("id", participant.id);

        await supabase.from("email_consent_events").insert([
          {
            participant_id: participant.id,
            submission_id: submissionId,
            email: payload.participantEmail,
            consent_type: "service",
            status: "granted",
            policy_version: consentVersion,
            statement_text: consentStatement,
            source: "assessment_submit",
            ip_address: ipAddress,
            user_agent: userAgent,
          },
          ...(payload.marketingConsent ? [{
            participant_id: participant.id,
            submission_id: submissionId,
            email: payload.participantEmail,
            consent_type: "marketing",
            status: "granted",
            policy_version: consentVersion,
            statement_text: "I agree to optional follow-up emails about growth resources, updates, and future offers.",
            source: "assessment_submit",
            ip_address: ipAddress,
            user_agent: userAgent,
          }] : []),
        ]);
      }

      if (payload.scoringMode === "review") {
        const reviewRows = results.map((result) => ({
          submission_id: submissionId,
          domain_id: result.domainId,
          ai_score: result.reflectionScore,
          ai_confidence: result.notes?.find((n) => n.startsWith("AI confidence:"))?.replace("AI confidence: ", "") ?? null,
          ai_explanation: result.notes?.find((n) => !n.startsWith("AI confidence:")) ?? null,
          final_score: result.reflectionScore,
          status: "pending",
        }));
        await supabase.from("reflection_reviews").insert(reviewRows);

        const { data: refreshedReviews } = await supabase
          .from("reflection_reviews")
          .select("id, submission_id, domain_id, ai_score, ai_confidence, ai_explanation, human_score, human_notes, final_score, status, created_at, updated_at")
          .eq("submission_id", submissionId);

        if (refreshedReviews?.length) {
          results = applyReviewOverrides({
            answers: payload.answers,
            reflections: payload.reflections,
            existingResults: results,
            reviews: refreshedReviews,
          });
        }
      }

      const unsubscribeToken = participant?.unsubscribe_token;
      const canSendServiceEmail = Boolean(participant?.service_emails_opt_in !== false && unsubscribeToken);

      await supabase.from("email_events").insert({
        participant_id: participant?.id ?? null,
        submission_id: submissionId,
        email: payload.participantEmail,
        category: "results",
        event_type: canSendServiceEmail ? "attempted" : "suppressed",
        provider_message: canSendServiceEmail ? "Preparing assessment result email." : "Suppressed because service email preference is off or token missing.",
      });

      if (!canSendServiceEmail) {
        emailStatus = "suppressed";
        await supabase.from("assessment_submissions").update({ email_delivery_status: emailStatus }).eq("id", submissionId);
      } else {
        try {
          const sendResult = await sendAssessmentResultEmail({
            to: payload.participantEmail,
            participantName: payload.participantName || "there",
            submissionId,
            publicToken: data.public_token,
            unsubscribeToken,
            overall: getOverallProfile(results),
            results,
          });

          emailStatus = sendResult.ok ? "sent" : sendResult.skipped ? "pending" : "failed";

          await supabase
            .from("assessment_submissions")
            .update({ email_delivery_status: emailStatus, emailed_at: sendResult.ok ? new Date().toISOString() : null })
            .eq("id", submissionId);

          await supabase.from("email_events").insert({
            participant_id: participant?.id ?? null,
            submission_id: submissionId,
            email: payload.participantEmail,
            category: "results",
            event_type: sendResult.ok ? "sent" : sendResult.skipped ? "preview_only" : "failed",
            provider_message: sendResult.ok ? "Assessment result email sent." : sendResult.skipped ? "SMTP not configured; preview only." : "Unknown email failure.",
          });
        } catch {
          emailStatus = "failed";
          await supabase.from("assessment_submissions").update({ email_delivery_status: "failed" }).eq("id", submissionId);
          await supabase.from("email_events").insert({
            participant_id: participant?.id ?? null,
            submission_id: submissionId,
            email: payload.participantEmail,
            category: "results",
            event_type: "failed",
            provider_message: "Result email send failed.",
          });
        }
      }

      if (payload.marketingConsent && participant?.unsubscribe_token) {
        try {
          const sendMarketing = await sendMarketingWelcomeEmail({
            to: payload.participantEmail,
            participantName: payload.participantName || "there",
            unsubscribeToken: participant.unsubscribe_token,
          });
          await supabase.from("email_events").insert({
            participant_id: participant?.id ?? null,
            submission_id: submissionId,
            email: payload.participantEmail,
            category: "marketing",
            event_type: sendMarketing.ok ? "sent" : sendMarketing.skipped ? "preview_only" : "failed",
            provider_message: sendMarketing.ok ? "Marketing welcome email sent." : sendMarketing.skipped ? "SMTP not configured; preview only." : "Marketing welcome failed.",
          });
        } catch {
          await supabase.from("email_events").insert({
            participant_id: participant?.id ?? null,
            submission_id: submissionId,
            email: payload.participantEmail,
            category: "marketing",
            event_type: "failed",
            provider_message: "Marketing welcome email failed.",
          });
        }
      }
    } catch {
      // Optional DB layer. The app still works without DB persistence.
    }

    await setConsentCookie();
    const finalOverall = getOverallProfile(results);
    return NextResponse.json({ submissionId, resultUrl, emailStatus, results, overall: finalOverall, consentVersion });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "Unknown error." }, { status: 500 });
  }
}
