import { NextRequest, NextResponse } from "next/server";
import { basicReflectionScore } from "@/lib/scoring";
import { scoreReflectionWithAI } from "@/lib/ai";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { domainId, reflection, mode } = body as { domainId: string; reflection: string; mode?: "basic" | "ai" };

    if (!domainId || typeof reflection !== "string") {
      return NextResponse.json({ error: "Missing domainId or reflection." }, { status: 400 });
    }

    if (mode === "ai") {
      const aiResult = await scoreReflectionWithAI(domainId, reflection);
      return NextResponse.json({ mode: "ai", ...aiResult });
    }

    const basic = basicReflectionScore(reflection, domainId);
    return NextResponse.json({ mode: "basic", ...basic });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "Unknown error." }, { status: 500 });
  }
}
