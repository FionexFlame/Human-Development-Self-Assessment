import Link from "next/link";
import { notFound } from "next/navigation";
import { getServiceSupabase } from "@/lib/supabase";
import { applyReviewOverrides, getOverallProfile } from "@/lib/scoring";
import { canViewSubmission } from "@/lib/access";
import { getGrowthPriorityText, getOverallNarrative, getStageInterpretation } from "@/lib/results";
import { ReflectionReviewRow, SubmissionRow } from "@/types";

async function getSubmission(id: string) {
  try {
    const supabase = getServiceSupabase();
    const [{ data: submission }, { data: reviews }] = await Promise.all([
      supabase
        .from("assessment_submissions")
        .select("id, participant_name, participant_email, scoring_mode, answers, reflections, domain_results, overall_profile, review_status, human_override, public_token, email_delivery_status, emailed_at, created_at, updated_at")
        .eq("id", id)
        .single(),
      supabase
        .from("reflection_reviews")
        .select("id, submission_id, domain_id, ai_score, ai_confidence, ai_explanation, human_score, human_notes, final_score, status, created_at, updated_at")
        .eq("submission_id", id),
    ]);

    return {
      submission: (submission ?? null) as SubmissionRow | null,
      reviews: (reviews ?? []) as ReflectionReviewRow[],
    };
  } catch {
    return { submission: null, reviews: [] };
  }
}

export default async function ResultsPage({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ token?: string }> }) {
  const { id } = await params;
  const { token } = await searchParams;
  const { submission, reviews } = await getSubmission(id);

  if (!submission) notFound();

  const allowed = await canViewSubmission(submission.public_token, token ?? null);
  if (!allowed) {
    return (
      <main className="container">
        <div className="card">
          <div className="badge">Private result</div>
          <h1 style={{ fontSize: 36, marginBottom: 8 }}>This result link needs a valid email token</h1>
          <p className="small" style={{ lineHeight: 1.7, maxWidth: 760 }}>
            This page is now protected. Open it from the emailed link, or sign in as admin to review it.
          </p>
          <div style={{ marginTop: 16, display: "flex", gap: 12, flexWrap: "wrap" }}>
            <Link className="button secondary" href="/assessment">Back to assessment</Link>
            <Link className="button secondary" href="/admin/login">Admin login</Link>
          </div>
        </div>
      </main>
    );
  }

  const results = reviews.length
    ? applyReviewOverrides({
        answers: submission.answers,
        reflections: submission.reflections,
        existingResults: submission.domain_results,
        reviews,
      })
    : submission.domain_results ?? [];
  const overall = getOverallProfile(results);
  const priorities = getGrowthPriorityText(results);

  return (
    <main className="container">
      <div className="card">
        <div className="badge">Saved result</div>
        <h1 style={{ fontSize: 40, marginBottom: 10 }}>Assessment results</h1>
        <p className="small" style={{ lineHeight: 1.7, maxWidth: 860 }}>
          Participant: <strong>{submission.participant_name || "Unnamed participant"}</strong> · Scoring mode: <strong>{submission.scoring_mode}</strong> · Review status: <strong>{submission.review_status}</strong> · Email status: <strong>{submission.email_delivery_status || "unknown"}</strong>
        </p>
        <div className="grid grid-3" style={{ marginTop: 20 }}>
          <div className="metric"><div className="small">Overall average</div><div style={{ fontSize: 28, fontWeight: 700 }}>{overall.average}</div></div>
          <div className="metric"><div className="small">Lowest 3 average</div><div style={{ fontSize: 28, fontWeight: 700 }}>{overall.lowestThreeAvg}</div></div>
          <div className="metric"><div className="small">Overall stage</div><div style={{ fontSize: 28, fontWeight: 700 }}>{overall.stage} — {overall.label}</div></div>
        </div>

        <div className="metric" style={{ marginTop: 20 }}>
          <h3 style={{ marginTop: 0 }}>Overall read</h3>
          <p className="small" style={{ lineHeight: 1.8 }}>{getOverallNarrative(overall)}</p>
        </div>

        <div style={{ marginTop: 20, display: "flex", gap: 12, flexWrap: "wrap" }}>
          <Link className="button secondary" href="/assessment">Back to assessment</Link>
          <Link className="button secondary" href="/admin/reviews">Open review queue</Link>
        </div>
      </div>

      <div className="card" style={{ marginTop: 20 }}>
        <h2 style={{ marginTop: 0 }}>Growth priorities</h2>
        <ul className="clean-list" style={{ marginTop: 12 }}>
          {priorities.map((item) => <li key={item}>{item}</li>)}
        </ul>
      </div>

      <div className="card" style={{ marginTop: 20 }}>
        <h2 style={{ marginTop: 0 }}>Domain breakdown</h2>
        <div className="grid" style={{ gap: 16, marginTop: 16 }}>
          {results.map((result) => (
            <div className="metric" key={result.domainId}>
              <div style={{ display: "flex", justifyContent: "space-between", gap: 12, flexWrap: "wrap" }}>
                <h3 style={{ marginTop: 0, marginBottom: 4 }}>{result.title}</h3>
                <div><strong>{result.finalScore}</strong> · Stage {result.stage}</div>
              </div>
              <p className="small" style={{ lineHeight: 1.8 }}>{getStageInterpretation(result.stage)}</p>
              <div className="grid grid-3" style={{ marginTop: 12 }}>
                <div className="metric"><div className="small">Core</div><div style={{ fontSize: 22, fontWeight: 700 }}>{result.coreAvg}</div></div>
                <div className="metric"><div className="small">Consistency</div><div style={{ fontSize: 22, fontWeight: 700 }}>{result.contradictionAvg}</div></div>
                <div className="metric"><div className="small">Reflection</div><div style={{ fontSize: 22, fontWeight: 700 }}>{result.reflectionScore}</div></div>
              </div>
              <p className="small" style={{ lineHeight: 1.8, marginTop: 12 }}><strong>Next growth task:</strong> {result.title}</p>
              {result.notes?.length ? (
                <ul className="clean-list" style={{ marginTop: 8 }}>
                  {result.notes.map((note) => <li key={note}>{note}</li>)}
                </ul>
              ) : null}
            </div>
          ))}
        </div>
      </div>
    </main>
  );
}
