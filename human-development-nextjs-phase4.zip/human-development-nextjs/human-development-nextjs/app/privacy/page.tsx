export default function PrivacyPage() {
  return (
    <main className="container narrow-container">
      <div className="card">
        <div className="badge">Privacy</div>
        <h1 style={{ fontSize: 36, marginBottom: 10 }}>Privacy notice</h1>
        <div className="small" style={{ lineHeight: 1.9 }}>
          <p>This site collects assessment answers, written reflections, email address, consent choices, and operational metadata needed to deliver and manage assessment results.</p>
          <p>We use this information to score the assessment, save the results, send requested result emails, support admin review, maintain email preferences, and keep a record of consent and unsubscribe events.</p>
          <p>Optional follow-up emails are separate from the requested result email. You can turn optional follow-up emails on or off in the preference center linked in each email.</p>
          <p>If you deploy this project publicly, replace this starter notice with a real policy reviewed for your jurisdiction, business model, storage practices, analytics stack, and email provider.</p>
        </div>
      </div>
    </main>
  );
}
