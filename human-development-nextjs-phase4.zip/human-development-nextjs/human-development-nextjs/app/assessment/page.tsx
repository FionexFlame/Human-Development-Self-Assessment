import AssessmentForm from "@/components/AssessmentForm";

export default function AssessmentPage() {
  return (
    <main className="container">
      <AssessmentForm />
    </main>
  );
}
