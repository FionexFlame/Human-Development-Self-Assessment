import Link from "next/link";
import { requireAdminAuth } from "@/lib/auth";
import { getServiceSupabase } from "@/lib/supabase";
import ReviewEditor from "@/components/admin/ReviewEditor";
import AdminLogoutButton from "@/components/admin/AdminLogoutButton";
import ResendEmailButton from "@/components/admin/ResendEmailButton";
import { ReflectionReviewRow, SubmissionRow } from "@/types";

async function getPendingReviews() {
  try {
    const supabase = getServiceSupabase();
    const { data } = await supabase
      .from("reflection_reviews")
      .select("id, submission_id, domain_id, ai_score, ai_confidence, ai_explanation, human_score, human_notes, final_score, status, created_at, updated_at")
      .order("created_at", { ascending: false });
    return (data ?? []) as ReflectionReviewRow[];
  } catch {
    return [];
  }
}

async function getSubmissionsIndex() {
  try {
    const supabase = getServiceSupabase();
    const { data } = await supabase
      .from("assessment_submissions")
      .select("id, participant_name, participant_email, public_token, email_delivery_status")
      .order("created_at", { ascending: false });

    return new Map((data ?? []).map((row: any) => [row.id, row as Partial<SubmissionRow>]));
  } catch {
    return new Map();
  }
}

export default async function AdminReviewsPage() {
  await requireAdminAuth();
  const [reviews, submissions] = await Promise.all([getPendingReviews(), getSubmissionsIndex()]);

  return (
    <main className="container">
      <div className="card">
        <div style={{ display: "flex", justifyContent: "space-between", gap: 12, flexWrap: "wrap", alignItems: "center" }}>
          <div>
            <div className="badge">Level 3 review queue</div>
            <h1 style={{ fontSize: 38, marginBottom: 8 }}>Reflection review admin</h1>
            <p className="small" style={{ maxWidth: 860, lineHeight: 1.7 }}>
              Phase 3 adds email-based participant handling. Each submission can now be privately opened through a tokenized email link and resent from admin when needed.
            </p>
          </div>
          <AdminLogoutButton />
        </div>

        {reviews.length === 0 ? (
          <p className="small">No review records found yet. If Supabase is not connected, this page will remain empty.</p>
        ) : (
          <div className="grid" style={{ gap: 18, marginTop: 20 }}>
            {reviews.map((row) => {
              const submission = submissions.get(row.submission_id);
              return (
                <div className="card subtle-card" key={row.id}>
                  <div style={{ display: "flex", justifyContent: "space-between", gap: 12, flexWrap: "wrap", alignItems: "center" }}>
                    <div>
                      <div style={{ fontWeight: 700 }}>{row.domain_id}</div>
                      <div className="small">Submission: <Link href={`/results/${row.submission_id}?token=${submission?.public_token || ""}`}>{row.submission_id}</Link></div>
                      <div className="small">Participant email: {submission?.participant_email || "unknown"}</div>
                      <div className="small">Email delivery: {submission?.email_delivery_status || "unknown"}</div>
                    </div>
                    <ResendEmailButton submissionId={row.submission_id} />
                  </div>
                  <ReviewEditor review={row} />
                </div>
              );
            })}
          </div>
        )}
      </div>
    </main>
  );
}
