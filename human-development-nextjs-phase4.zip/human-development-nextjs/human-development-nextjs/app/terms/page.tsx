export default function TermsPage() {
  return (
    <main className="container narrow-container">
      <div className="card">
        <div className="badge">Terms</div>
        <h1 style={{ fontSize: 36, marginBottom: 10 }}>Terms of use</h1>
        <div className="small" style={{ lineHeight: 1.9 }}>
          <p>This assessment is a self-reflection and growth tool. It is not medical advice, not a diagnosis, and not a substitute for licensed mental health care.</p>
          <p>By using the site, participants understand that scores are interpretive and may use rule-based logic, AI-assisted scoring, and human review depending on the selected mode.</p>
          <p>If you deploy this project commercially, replace this starter page with a jurisdiction-specific terms document reviewed by counsel.</p>
        </div>
      </div>
    </main>
  );
}
