import Link from "next/link";

export default function HomePage() {
  return (
    <main className="container">
      <div className="card">
        <div className="badge">Deployable Next.js scaffold</div>
        <h1 style={{ fontSize: 44, marginBottom: 12 }}>Human Development Assessment website</h1>
        <p className="small" style={{ maxWidth: 850, lineHeight: 1.7 }}>
          This project now includes phase 4 with a compliance-oriented email layer. The assessment separates requested service emails from optional follow-up emails, records consent events, adds a preference center and unsubscribe flow, and suppresses email sends when preferences are turned off.
          Level 1 runs locally with rule-based scoring. Level 2 adds AI reflection scoring. Level 3 adds AI plus human review overrides.
        </p>
        <div className="grid grid-3" style={{ marginTop: 24 }}>
          <div className="metric">
            <h3>Level 1</h3>
            <p className="small">Fastest and cheapest. Good for MVP launch. Reflection scores are heuristic only.</p>
          </div>
          <div className="metric">
            <h3>Level 2</h3>
            <p className="small">AI scores each reflection with a rubric for honesty, specificity, self-awareness, and developmental capacity.</p>
          </div>
          <div className="metric">
            <h3>Level 3</h3>
            <p className="small">AI creates draft reflection scores, then a human reviewer can confirm or override them before resending final results.</p>
          </div>
        </div>
        <div style={{ marginTop: 24, display: "flex", gap: 12, flexWrap: "wrap" }}>
          <Link className="button" href="/assessment">Open assessment</Link>
          <Link className="button secondary" href="/my-results">My results</Link>
          <Link className="button secondary" href="/admin/reviews">Open review queue</Link>
          <Link className="button secondary" href="/admin/login">Admin login</Link>
          <Link className="button secondary" href="/privacy">Privacy</Link>
          <Link className="button secondary" href="/terms">Terms</Link>
        </div>
      </div>
    </main>
  );
}
